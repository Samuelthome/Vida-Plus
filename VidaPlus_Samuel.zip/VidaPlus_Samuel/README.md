# Sistema de Gestão Hospitalar e de Serviços de Saúde (SGHSS)

Sistema desenvolvido para a instituição VidaPlus para gerenciamento de hospitais, clínicas, laboratórios e serviços de home care.

## Funcionalidades Principais

- Cadastro e Atendimento de Pacientes
- Gestão de Profissionais de Saúde
- Administração Hospitalar
- Telemedicina
- Segurança e Compliance

## Tecnologias Utilizadas

### Backend
- Python 3.9+
- FastAPI
- SQLAlchemy
- PostgreSQL
- JWT para autenticação

### Frontend
- React
- TypeScript
- Material-UI
- Axios

## Requisitos

- Python 3.9+
- Node.js 16+
- PostgreSQL 13+
- Docker (opcional)

## Instalação

1. Clone o repositório
2. Configure o ambiente virtual Python:
```bash
python -m venv venv
source venv/bin/activate  # Linux/Mac
venv\Scripts\activate     # Windows
```

3. Instale as dependências do backend:
```bash
cd backend
pip install -r requirements.txt
```

4. Instale as dependências do frontend:
```bash
cd frontend
npm install
```

5. Configure as variáveis de ambiente:
```bash
cp .env.example .env
```

6. Inicie o servidor de desenvolvimento:
```bash
# Backend
cd backend
uvicorn main:app --reload

# Frontend
cd frontend
npm start
```

## Estrutura do Projeto

```
sghss/
├── backend/
│   ├── app/
│   │   ├── api/
│   │   ├── core/
│   │   ├── models/
│   │   └── services/
│   ├── tests/
│   └── requirements.txt
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   ├── pages/
│   │   └── services/
│   └── package.json
└── README.md
```

## Documentação da API

A documentação da API estará disponível em `http://localhost:3000/docs` após iniciar o servidor backend.

## Testando no Postman

Para autenticar e testar as rotas protegidas, utilize as seguintes credenciais padrão:

- **Usuário:** admin@sghss.com
- **Senha:** admin

Exemplo de login:
1. Faça uma requisição POST para `/api/v1/login/access-token` com o corpo:
```json
{
  "username": "admin@sghss.com",
  "password": "admin"
}
```
2. Use o token de acesso retornado para autenticar as demais rotas protegidas.

## Testes

```bash
# Backend
cd backendL
pytest

# Frontend
cd frontend
npm test
```

## Licença

Este projeto está sob a licença MIT. 