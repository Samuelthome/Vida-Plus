from typing import Any, Dict, Optional
from pathlib import Path
from jinja2 import Environment, select_autoescape, PackageLoader
from app.core.config import settings

env = Environment(
    loader=PackageLoader("app", "templates"),
    autoescape=select_autoescape(["html", "xml"]),
)

def send_email(
    email_to: str,
    subject_template: str = "",
    html_template: str = "",
    environment: Dict[str, Any] = {},
) -> None:
    """
    Função para envio de e-mails.
    Em produção, implementar integração com serviço de e-mail.
    """
    # TODO: Implementar integração com serviço de e-mail
    print(f"Email enviado para {email_to}")
    print(f"Assunto: {subject_template}")
    print(f"Conteúdo: {html_template}")
    print(f"Variáveis: {environment}")

def send_new_account_email(email_to: str, username: str, password: str) -> None:
    project_name = settings.PROJECT_NAME
    subject = f"{project_name} - Nova conta criada"
    with open(Path("app/templates/new_account.html")) as f:
        template_str = f.read()
    link = f"{settings.SERVER_HOST}/login"
    send_email(
        email_to=email_to,
        subject_template=subject,
        html_template=template_str,
        environment={
            "project_name": settings.PROJECT_NAME,
            "username": username,
            "password": password,
            "link": link,
        },
    )

def send_reset_password_email(email_to: str, email: str, token: str) -> None:
    project_name = settings.PROJECT_NAME
    subject = f"{project_name} - Recuperação de senha"
    with open(Path("app/templates/reset_password.html")) as f:
        template_str = f.read()
    link = f"{settings.SERVER_HOST}/reset-password?token={token}"
    send_email(
        email_to=email_to,
        subject_template=subject,
        html_template=template_str,
        environment={
            "project_name": settings.PROJECT_NAME,
            "username": email,
            "link": link,
        },
    ) 