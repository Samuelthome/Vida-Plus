from typing import Optional
from datetime import datetime
from pydantic import BaseModel, EmailStr


# Propriedades compartilhadas
class UserBase(BaseModel):
    email: Optional[EmailStr] = None
    is_active: Optional[bool] = True
    is_superuser: bool = False
    full_name: Optional[str] = None
    user_type: Optional[str] = None
    crm: Optional[str] = None
    coren: Optional[str] = None
    cpf: Optional[str] = None
    phone: Optional[str] = None
    address: Optional[str] = None
    birth_date: Optional[str] = None


# Propriedades para criar usuário
class UserCreate(UserBase):
    email: EmailStr
    password: str
    full_name: str
    user_type: str


# Propriedades para atualizar usuário
class UserUpdate(UserBase):
    password: Optional[str] = None


# Propriedades compartilhadas para leitura/resposta
class UserInDBBase(UserBase):
    id: Optional[int] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


# Propriedades adicionais armazenadas no DB
class UserInDB(UserInDBBase):
    hashed_password: str


# Propriedades retornadas ao cliente
class User(UserInDBBase):
    pass 