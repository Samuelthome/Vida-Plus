from typing import Optional
from datetime import datetime
from pydantic import BaseModel


# Propriedades compartilhadas
class MedicalRecordBase(BaseModel):
    patient_id: Optional[int] = None
    doctor_id: Optional[int] = None
    diagnosis: Optional[str] = None
    treatment: Optional[str] = None
    notes: Optional[str] = None


# Propriedades para criar prontuário
class MedicalRecordCreate(MedicalRecordBase):
    patient_id: int
    diagnosis: str
    treatment: str


# Propriedades para atualizar prontuário
class MedicalRecordUpdate(MedicalRecordBase):
    pass


# Propriedades retornadas ao cliente
class MedicalRecord(MedicalRecordBase):
    id: int
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True 