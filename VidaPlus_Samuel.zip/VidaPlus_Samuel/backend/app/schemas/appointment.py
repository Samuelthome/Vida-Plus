from typing import Optional
from pydantic import BaseModel
from datetime import datetime
from app.models.appointment import AppointmentType, AppointmentStatus


# Shared properties
class AppointmentBase(BaseModel):
    patient_id: Optional[int] = None
    doctor_id: Optional[int] = None
    appointment_date: Optional[datetime] = None
    appointment_type: Optional[AppointmentType] = None
    status: Optional[AppointmentStatus] = None
    notes: Optional[str] = None


# Properties to receive via API on creation
class AppointmentCreate(AppointmentBase):
    patient_id: int
    doctor_id: int
    appointment_date: datetime
    appointment_type: AppointmentType
    status: AppointmentStatus = AppointmentStatus.SCHEDULED


# Properties to receive via API on update
class AppointmentUpdate(AppointmentBase):
    pass


# Properties shared by models stored in DB
class AppointmentInDBBase(AppointmentBase):
    id: int
    patient_id: int
    doctor_id: int
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True


# Additional properties to return via API
class Appointment(AppointmentInDBBase):
    pass


# Additional properties stored in DB
class AppointmentInDB(AppointmentInDBBase):
    pass 