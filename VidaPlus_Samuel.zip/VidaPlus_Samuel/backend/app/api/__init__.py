from .api import api_router
from . import deps  # noqa

__all__ = ["api_router"] 