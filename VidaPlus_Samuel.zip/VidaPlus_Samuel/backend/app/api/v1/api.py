from fastapi import APIRouter
from app.api.v1.endpoints import auth, users, medical_records, appointments

api_router = APIRouter()

# Rotas de autenticação
api_router.include_router(auth.router, prefix="/auth", tags=["auth"])

# Rotas de usuários
api_router.include_router(users.router, prefix="/users", tags=["users"])

# Rotas de prontuários médicos
api_router.include_router(medical_records.router, prefix="/medical-records", tags=["medical-records"])

# Rotas de agendamentos
api_router.include_router(appointments.router, prefix="/appointments", tags=["appointments"]) 