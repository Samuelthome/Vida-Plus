from typing import Any, List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app import crud, models, schemas
from app.api import deps

router = APIRouter()

@router.get("/", response_model=List[schemas.MedicalRecord])
def read_medical_records(
    db: Session = Depends(deps.get_db),
    skip: int = 0,
    limit: int = 100,
    current_user: models.User = Depends(deps.get_current_active_user),
) -> Any:
    """
    Retrieve medical records.
    """
    if current_user.user_type in [models.UserType.DOCTOR, models.UserType.ADMIN]:
        medical_records = crud.medical_record.get_multi(db, skip=skip, limit=limit)
    elif current_user.user_type == models.UserType.PATIENT:
        medical_records = crud.medical_record.get_multi_by_patient(
            db=db, patient_id=current_user.id, skip=skip, limit=limit
        )
    else:
        raise HTTPException(
            status_code=400, detail="The user doesn't have enough privileges"
        )
    return medical_records

@router.post("/", response_model=schemas.MedicalRecord)
def create_medical_record(
    *,
    db: Session = Depends(deps.get_db),
    medical_record_in: schemas.MedicalRecordCreate,
    current_user: models.User = Depends(deps.get_current_active_user),
) -> Any:
    """
    Create new medical record.
    """
    if current_user.user_type != models.UserType.DOCTOR:
        raise HTTPException(
            status_code=400, detail="Only doctors can create medical records"
        )
    medical_record = crud.medical_record.create_with_doctor(
        db=db, obj_in=medical_record_in, doctor_id=current_user.id
    )
    return medical_record

@router.get("/{id}", response_model=schemas.MedicalRecord)
def read_medical_record(
    *,
    db: Session = Depends(deps.get_db),
    id: int,
    current_user: models.User = Depends(deps.get_current_active_user),
) -> Any:
    """
    Get medical record by ID.
    """
    medical_record = crud.medical_record.get(db=db, id=id)
    if not medical_record:
        raise HTTPException(status_code=404, detail="Medical record not found")
    if (
        current_user.user_type not in [models.UserType.DOCTOR, models.UserType.ADMIN]
        and medical_record.patient_id != current_user.id
    ):
        raise HTTPException(
            status_code=400, detail="The user doesn't have enough privileges"
        )
    return medical_record

@router.put("/{id}", response_model=schemas.MedicalRecord)
def update_medical_record(
    *,
    db: Session = Depends(deps.get_db),
    id: int,
    medical_record_in: schemas.MedicalRecordUpdate,
    current_user: models.User = Depends(deps.get_current_active_user),
) -> Any:
    """
    Update medical record.
    """
    medical_record = crud.medical_record.get(db=db, id=id)
    if not medical_record:
        raise HTTPException(status_code=404, detail="Medical record not found")
    if current_user.user_type != models.UserType.DOCTOR:
        raise HTTPException(
            status_code=400, detail="Only doctors can update medical records"
        )
    medical_record = crud.medical_record.update(
        db=db, db_obj=medical_record, obj_in=medical_record_in
    )
    return medical_record 