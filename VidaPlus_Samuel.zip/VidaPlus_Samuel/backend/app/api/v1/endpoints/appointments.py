from typing import Any, List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app import crud, models, schemas
from app.api import deps

router = APIRouter()

@router.get("/", response_model=List[schemas.Appointment])
def read_appointments(
    db: Session = Depends(deps.get_db),
    skip: int = 0,
    limit: int = 100,
    current_user: models.User = Depends(deps.get_current_active_user),
) -> Any:
    """
    Retrieve appointments.
    """
    if current_user.user_type in [models.UserType.DOCTOR, models.UserType.ADMIN]:
        appointments = crud.appointment.get_multi_by_doctor(
            db=db, doctor_id=current_user.id, skip=skip, limit=limit
        )
    elif current_user.user_type == models.UserType.PATIENT:
        appointments = crud.appointment.get_multi_by_patient(
            db=db, patient_id=current_user.id, skip=skip, limit=limit
        )
    else:
        raise HTTPException(
            status_code=400, detail="The user doesn't have enough privileges"
        )
    return appointments

@router.post("/", response_model=schemas.Appointment)
def create_appointment(
    *,
    db: Session = Depends(deps.get_db),
    appointment_in: schemas.AppointmentCreate,
    current_user: models.User = Depends(deps.get_current_active_user),
) -> Any:
    """
    Create new appointment.
    """
    if current_user.user_type not in [models.UserType.PATIENT, models.UserType.ADMIN]:
        raise HTTPException(
            status_code=400, detail="Only patients can create appointments"
        )
    appointment = crud.appointment.create_with_patient(
        db=db, obj_in=appointment_in, patient_id=current_user.id
    )
    return appointment

@router.get("/{id}", response_model=schemas.Appointment)
def read_appointment(
    *,
    db: Session = Depends(deps.get_db),
    id: int,
    current_user: models.User = Depends(deps.get_current_active_user),
) -> Any:
    """
    Get appointment by ID.
    """
    appointment = crud.appointment.get(db=db, id=id)
    if not appointment:
        raise HTTPException(status_code=404, detail="Appointment not found")
    if (
        current_user.user_type not in [models.UserType.DOCTOR, models.UserType.ADMIN]
        and appointment.patient_id != current_user.id
    ):
        raise HTTPException(
            status_code=400, detail="The user doesn't have enough privileges"
        )
    return appointment

@router.put("/{id}", response_model=schemas.Appointment)
def update_appointment(
    *,
    db: Session = Depends(deps.get_db),
    id: int,
    appointment_in: schemas.AppointmentUpdate,
    current_user: models.User = Depends(deps.get_current_active_user),
) -> Any:
    """
    Update appointment.
    """
    appointment = crud.appointment.get(db=db, id=id)
    if not appointment:
        raise HTTPException(status_code=404, detail="Appointment not found")
    if current_user.user_type not in [models.UserType.DOCTOR, models.UserType.ADMIN]:
        raise HTTPException(
            status_code=400, detail="Only doctors can update appointments"
        )
    appointment = crud.appointment.update(
        db=db, db_obj=appointment, obj_in=appointment_in
    )
    return appointment

@router.delete("/{id}", response_model=schemas.Appointment)
def delete_appointment(
    *,
    db: Session = Depends(deps.get_db),
    id: int,
    current_user: models.User = Depends(deps.get_current_active_user),
) -> Any:
    """
    Delete appointment.
    """
    appointment = crud.appointment.get(db=db, id=id)
    if not appointment:
        raise HTTPException(status_code=404, detail="Appointment not found")
    if current_user.user_type not in [models.UserType.DOCTOR, models.UserType.ADMIN]:
        raise HTTPException(
            status_code=400, detail="Only doctors can delete appointments"
        )
    appointment = crud.appointment.remove(db=db, id=id)
    return appointment 