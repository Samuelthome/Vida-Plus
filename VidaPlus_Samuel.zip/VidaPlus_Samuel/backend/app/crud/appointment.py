from typing import List, Optional
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
from fastapi.encoders import jsonable_encoder
from sqlalchemy import and_, or_

from app.crud.base import CRUDBase
from app.models.appointment import Appointment
from app.schemas.appointment import AppointmentCreate, AppointmentUpdate

class CRUDAppointment(CRUDBase[Appointment, AppointmentCreate, AppointmentUpdate]):
    def get_multi_by_doctor(
        self, db: Session, *, doctor_id: int, skip: int = 0, limit: int = 100
    ) -> List[Appointment]:
        return (
            db.query(self.model)
            .filter(Appointment.doctor_id == doctor_id)
            .offset(skip)
            .limit(limit)
            .all()
        )

    def get_multi_by_patient(
        self, db: Session, *, patient_id: int, skip: int = 0, limit: int = 100
    ) -> List[Appointment]:
        return (
            db.query(self.model)
            .filter(Appointment.patient_id == patient_id)
            .offset(skip)
            .limit(limit)
            .all()
        )

    def create_with_doctor(
        self, db: Session, *, obj_in: AppointmentCreate, doctor_id: int
    ) -> Appointment:
        obj_in_data = obj_in.dict()
        db_obj = self.model(**obj_in_data, doctor_id=doctor_id)
        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj

    def create_with_patient(
        self, db: Session, *, obj_in: AppointmentCreate, patient_id: int
    ) -> Appointment:
        obj_in_data = obj_in.dict()
        db_obj = self.model(**obj_in_data, patient_id=patient_id)
        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj

    def get_multi_by_user(
        self, db: Session, *, user_id: int, skip: int = 0, limit: int = 100
    ) -> List[Appointment]:
        return (
            db.query(self.model)
            .filter(
                (self.model.doctor_id == user_id) | (self.model.patient_id == user_id)
            )
            .offset(skip)
            .limit(limit)
            .all()
        )

    def doctor_has_conflict(
        self, db: Session, *, doctor_id: int, appointment_date: datetime, exclude_id: int = None
    ) -> bool:
        # Verifica se há outra consulta no mesmo horário (com margem de 30 minutos)
        start_time = appointment_date - timedelta(minutes=30)
        end_time = appointment_date + timedelta(minutes=30)
        
        query = db.query(self.model).filter(
            and_(
                self.model.doctor_id == doctor_id,
                self.model.appointment_date.between(start_time, end_time)
            )
        )
        
        if exclude_id:
            query = query.filter(self.model.id != exclude_id)
        
        return db.query(query.exists()).scalar()

appointment = CRUDAppointment(Appointment) 