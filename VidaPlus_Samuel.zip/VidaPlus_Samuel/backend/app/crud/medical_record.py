from typing import List, Optional
from fastapi.encoders import jsonable_encoder
from sqlalchemy.orm import Session

from app.crud.base import CRUDBase
from app.models.medical_record import MedicalRecord
from app.schemas.medical_record import MedicalRecordCreate, MedicalRecordUpdate

class CRUDMedicalRecord(CRUDBase[MedicalRecord, MedicalRecordCreate, MedicalRecordUpdate]):
    def get_multi_by_doctor(
        self, db: Session, *, doctor_id: int, skip: int = 0, limit: int = 100
    ) -> List[MedicalRecord]:
        return (
            db.query(self.model)
            .filter(MedicalRecord.doctor_id == doctor_id)
            .offset(skip)
            .limit(limit)
            .all()
        )

    def get_multi_by_patient(
        self, db: Session, *, patient_id: int, skip: int = 0, limit: int = 100
    ) -> List[MedicalRecord]:
        return (
            db.query(self.model)
            .filter(MedicalRecord.patient_id == patient_id)
            .offset(skip)
            .limit(limit)
            .all()
        )

    def create_with_doctor(
        self, db: Session, *, obj_in: MedicalRecordCreate, doctor_id: int
    ) -> MedicalRecord:
        obj_in_data = jsonable_encoder(obj_in)
        db_obj = self.model(**obj_in_data, doctor_id=doctor_id)
        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj

    def get_multi_by_user(
        self, db: Session, *, user_id: int, skip: int = 0, limit: int = 100
    ) -> List[MedicalRecord]:
        return (
            db.query(self.model)
            .filter(
                (self.model.doctor_id == user_id) | (self.model.patient_id == user_id)
            )
            .offset(skip)
            .limit(limit)
            .all()
        )

medical_record = CRUDMedicalRecord(MedicalRecord) 