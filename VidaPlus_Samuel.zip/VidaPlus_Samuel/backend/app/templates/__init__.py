"""
Templates para envio de e-mails
""" 