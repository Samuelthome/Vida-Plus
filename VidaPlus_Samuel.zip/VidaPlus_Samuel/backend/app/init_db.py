import logging
from sqlalchemy.orm import Session

from app.db.session import engine, SessionLocal
from app.models import user  # Importa todos os modelos
from app.models.base import Base
from app.core.config import settings
from app.core.security import get_password_hash

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def init_db() -> None:
    # Importa todos os modelos antes de criar as tabelas
    from app.models import user
    Base.metadata.create_all(bind=engine)
    
    # Criar usuário admin se não existir
    db = SessionLocal()
    try:
        user_admin = db.query(user.User).filter(user.User.email == settings.FIRST_SUPERUSER).first()
        if not user_admin:
            user_admin = user.User(
                email=settings.FIRST_SUPERUSER,
                hashed_password=get_password_hash(settings.FIRST_SUPERUSER_PASSWORD),
                full_name="Administrador",
                user_type="ADMIN",
                is_superuser=True
            )
            db.add(user_admin)
            db.commit()
            logger.info("Usuário admin criado com sucesso!")
        else:
            logger.info("Usuário admin já existe!")
    except Exception as e:
        logger.error(f"Erro ao criar usuário admin: {e}")
    finally:
        db.close()

if __name__ == "__main__":
    logger.info("Criando tabelas e dados iniciais...")
    init_db()
    logger.info("Inicialização concluída!") 