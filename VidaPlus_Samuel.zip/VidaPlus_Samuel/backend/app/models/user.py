from datetime import datetime
from enum import Enum
from sqlalchemy import Boolean, Column, DateTime, Enum as SQLEnum, Integer, String
from sqlalchemy.orm import relationship

from app.models.base import Base


class UserType(str, Enum):
    ADMIN = "ADMIN"
    DOCTOR = "DOCTOR"
    NURSE = "NURSE"
    PATIENT = "PATIENT"


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    full_name = Column(String)
    user_type = Column(String, default="USER")  # ADMIN, USER, etc
    is_active = Column(Boolean(), default=True)
    is_superuser = Column(Boolean(), default=False)
    crm = Column(String, nullable=True)  # Para médicos
    coren = Column(String, nullable=True)  # Para enfermeiros
    cpf = Column(String, unique=True, index=True)
    phone = Column(String)
    address = Column(String)
    birth_date = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    # Relacionamentos
    medical_records_as_doctor = relationship("MedicalRecord", back_populates="doctor", foreign_keys="MedicalRecord.doctor_id")
    medical_records_as_patient = relationship("MedicalRecord", back_populates="patient", foreign_keys="MedicalRecord.patient_id")
    appointments_as_doctor = relationship("Appointment", back_populates="doctor", foreign_keys="Appointment.doctor_id")
    appointments_as_patient = relationship("Appointment", back_populates="patient", foreign_keys="Appointment.patient_id") 