"""
SGHSS - Sistema de Gestão Hospitalar e Serviços de Saúde
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import settings
from app.api.v1.endpoints import auth, users, medical_records, appointments
from . import crud, models, schemas  # noqa

app = FastAPI(
    title=settings.PROJECT_NAME,
    openapi_url="/docs"
)

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Rotas de autenticação
app.include_router(auth.router, prefix="/auth", tags=["auth"])

# Rotas de usuários
app.include_router(users.router, prefix="/users", tags=["users"])

# Rotas de prontuários médicos
app.include_router(medical_records.router, prefix="/medical-records", tags=["medical-records"])

# Rotas de agendamentos
app.include_router(appointments.router, prefix="/appointments", tags=["appointments"]) 